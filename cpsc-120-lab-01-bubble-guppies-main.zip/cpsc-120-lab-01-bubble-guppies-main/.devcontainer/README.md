# CPP-Lab-Devcontainer

This repository is meant to be used as a submodule for C++ programming lab assignments. Dockerfile and configuration for the devcontainer used in GitHub Codespaces.

The Docker image is huge because we use clang/LLVM.
