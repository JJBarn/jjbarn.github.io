// The name of the file is hello.cc
// Alexander Arciniega
// aarciniega354@gmail.com
// @ArciSlayer21
// Partners: @JJBarn

#include <iostream>

int main(int argc, const char *argv[]) {
  std::cout << "Hello Joshua and Alexander!\n";
  return 0;
}
