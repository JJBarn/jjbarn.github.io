# CPP-Lab-GitHub

This repository is meant to be used as a submodule for C++ programming lab assignments. All GitHub workflows used for C++ lab assignments is in this repository.
