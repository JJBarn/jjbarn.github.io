Joshua Barnson
Joshbarnson@csu.fullerton.edu
@JJBarn

Ethan Chien
ethanchien@csu.fullerton.edu
@toodols