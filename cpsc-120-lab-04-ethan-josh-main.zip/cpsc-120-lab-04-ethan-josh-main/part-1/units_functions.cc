
#include "units_functions.h"

// Convert mililiters to teaspoons
double MlToTsp(double volume) { return volume / 4.929; }

// Convert mililiters to tablespoons
double MlToTbsp(double volume) { return MlToTsp(volume) / 3; }

// Convert mililiters to fluid ounces
double MlToOz(double volume) { return MlToTbsp(volume) / 2; }

// Convert mililiters to cups
double MlToCup(double volume) { return MlToOz(volume) / 8; }