# CPP-Lab-Actions

This repository is meant to be used as a submodule for C++ programming lab assignments. Supporting Python scripts and tools to facilitate student lab creation and testing.