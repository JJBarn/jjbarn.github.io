Joshua Barnson
joshbarnson@csu.fullerton.edu
@JJBarn
Chad Ibarra
chadibarra8@csu.fullerton.edu
@chadibarra8