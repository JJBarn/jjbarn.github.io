
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

#include "spelling_functions.h"

int main(int argc, char* argv[]) {
  std::vector<std::string> command{argv, argv + argc};

  if (argc != 2) {
    std::cout << "error: you must give a document filename\n";
    return 1;
  }

  std::string input_file_stream{(command.at(1))};

  std::vector<std::string> dictionary = ReadWords("words.txt");
  std::vector<std::string> document = ReadWords(input_file_stream);

  std::vector<std::string> misspelled = MisspelledWords(dictionary, document);

  std::cout << "spelling errors: \n";

  for (const auto& word : misspelled) {
    std::cout << word << " ";
  }

  std::cout << "\n";

  return 0;
}
