
#include "spelling_functions.h"

#include <fstream>

std::vector<std::string> ReadWords(const std::string& filename) {
  std::vector<std::string> words;
  std::ifstream files(filename);
  std::string word;
  while (files >> word) {
    words.push_back(word);
  }
  return words;
}

bool InDictionary(const std::vector<std::string>& dictionary,
                  const std::string& word) {
  for (auto const& dic_word : dictionary) {
    if (dic_word == word) {
      return true;
    }
  }

  return false;
}

std::vector<std::string> MisspelledWords(
    const std::vector<std::string>& dictionary,
    const std::vector<std::string>& document) {
  std::vector<std::string> misspelled;

  for (auto const& entry : document) {
    if (!InDictionary(dictionary, entry)) {
      misspelled.push_back(entry);
    }
  }

  return misspelled;
}
