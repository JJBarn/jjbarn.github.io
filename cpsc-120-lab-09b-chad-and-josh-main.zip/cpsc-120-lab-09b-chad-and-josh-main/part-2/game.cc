
#include <fstream>
#include <iostream>
#include <string>

int main(int argc, char* argv[]) {
  std::ifstream input_file{"secret.dat"};

  if (!input_file.good()) {
    std::cout << "error: cannot read secret.dat\n";
    return 1;
  }

  int file_output = 0;
  int num = 0;
  input_file >> file_output;
  num = file_output;
  std::cout << num << std::endl;

  if (num < 1 || num > 10) {
    std::cout << "error: secret.dat malformed\n";
    return 1;
  }

  int guess = 0;
  std::cout << "Enter your guess: ";
  std::cin >> guess;

  if (guess == num) {
    std::cout << "Correct, you win!\n";
  } else {
    std::cout << "Incorrect, the secret number was " << num << ", you lose.\n";
  }
  input_file.close();

  return 0;
}
