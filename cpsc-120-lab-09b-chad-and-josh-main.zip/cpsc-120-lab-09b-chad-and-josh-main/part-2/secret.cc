#include <fstream>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char* argv[]) {
  std::vector<std::string> command{argv, argv + argc};
  if (argc != 2) {
    std::cout << "error: you must provide a secret number\n";
    return 1;
  }

  std::string secret_number = command.at(1);
  int secret_num = std::stoi(secret_number);
  if (secret_num < 1 || secret_num > 10) {
    std::cout << "error: secret number must be between 1 and 10\n";
    return 1;
  }
  std::ofstream output_file("secret.dat");
  if (!output_file.is_open()) {
    std::cout << "error: unable to open file secret.dat\n";
    return 1;
  }
  output_file << secret_num;

  std::cout << "Secret number " << secret_num
            << " written to secret.dat successfully.\n";

  return 0;
}
